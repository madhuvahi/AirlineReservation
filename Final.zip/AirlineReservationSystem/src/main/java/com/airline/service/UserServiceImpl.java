package com.airline.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.airline.dao.UserDao;
import com.airline.model.Flight;
import com.airline.model.Login;
import com.airline.model.User;

public class UserServiceImpl implements UserService {
	@Autowired
	UserDao userDao;
	public void register(User user){
		userDao.register(user);
	}
	public User validateUser(Login login){
		return userDao.validateUser(login);
	}
	public List<Flight> findFlight(Flight flight) {
		return userDao.findFlight(flight);
	}

}
