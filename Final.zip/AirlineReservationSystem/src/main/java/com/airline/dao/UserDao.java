package com.airline.dao;

import java.util.List;

import com.airline.model.Flight;
import com.airline.model.Login;
import com.airline.model.User;

public interface UserDao {
	
	void register(User user);
	User validateUser(Login login);
	public List<Flight> findFlight(Flight flight);
	

}
