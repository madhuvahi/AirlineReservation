package com.airline.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.jdbc.core.RowMapper;

import com.airline.model.Flight;
import com.airline.model.Login;
import com.airline.model.User;

public class UserDaoImpl implements UserDao {

	 @Autowired
	  DataSource datasource;
	 
	 @Autowired
	  JdbcTemplate jdbcTemplate;

	public void register(User user) {
		String sql = "insert into customerdetails(name,password,city,gender,mailid) values(?,?,?,?,?)";
		
		jdbcTemplate.update(sql, new Object[] { user.getName(), user.getPassword(), user.getCity(),
			    user.getGender(), user.getMailid() });
	}
	public User validateUser(Login login) {
		String sql = "select * from customerdetails where name='" + login.getName() + "' and password='" + login.getPassword()
	    + "'";
		 List<User> users = jdbcTemplate.query(sql, new UserMapper());
		    return users.size() > 0 ? users.get(0) : null;
		
	}
	public List<Flight> findFlight(Flight flight){
		return jdbcTemplate.query("select * from inventory where flightfrom='" + flight.getFlightfrom() + "' and  flightto='" + flight.getFlightto() 
	    + "'",new RowMapper<Flight>() {
			public Flight mapRow(ResultSet rs, int arg1) throws SQLException {
				Flight flight=new Flight();
				 flight.setFlightid(rs.getInt("flightid"));
				 flight.setFlightfrom(rs.getString("flightfrom"));
				 flight.setFlightto(rs.getString("flightto"));
				 flight.setFlightname(rs.getString("flightname"));
			     flight.setDeparturedate(rs.getString("departuredate"));
			     flight.setDeparturetime(rs.getString("departuretime"));
			     flight.setArrivaltime(rs.getString("arrivaltime"));
			     flight.setSeat(rs.getInt("seat"));
			    
			     return flight;
				
			}
			
			});
}
	
	class UserMapper implements RowMapper<User>{
		public User mapRow(ResultSet rs, int arg1) throws SQLException {
		    User user = new User();
		    user.setName(rs.getString("name"));
		    user.setPassword(rs.getString("password"));
		    user.setCity(rs.getString("city"));
		    user.setGender(rs.getString("gender"));
		    user.setMailid(rs.getString("mailid"));
		    
		    return user;
		  }
	}
		
}
	
	



