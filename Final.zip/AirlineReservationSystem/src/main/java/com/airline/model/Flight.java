package com.airline.model;

public class Flight {
	
	private int flightid;
	private String flightfrom;
	private String flightto;
	private String departuredate;
	private String flightname;
	private String departuretime;
	private String arrivaltime;
	private int seat;
	
	
	
	
	public int getFlightid() {
		return flightid;
	}
	public void setFlightid(int flightid) {
		this.flightid = flightid;
	}
	public String getFlightname() {
		return flightname;
	}
	public void setFlightname(String flightname) {
		this.flightname = flightname;
	}
	public String getDeparturetime() {
		return departuretime;
	}
	public void setDeparturetime(String departuretime) {
		this.departuretime = departuretime;
	}
	public String getArrivaltime() {
		return arrivaltime;
	}
	public void setArrivaltime(String arrivaltime) {
		this.arrivaltime = arrivaltime;
	}
	public int getSeat() {
		return seat;
	}
	public void setSeat(int seat) {
		this.seat = seat;
	}
	public String getFlightfrom() {
		return flightfrom;
	}
	public void setFlightfrom(String flightfrom) {
		this.flightfrom = flightfrom;
	}
	public String getFlightto() {
		return flightto;
	}
	public void setFlightto(String flightto) {
		this.flightto = flightto;
	}
	public String getDeparturedate() {
		return departuredate;
	}
	public void setDeparturedate(String departuredate) {
		this.departuredate = departuredate;
	}
}
